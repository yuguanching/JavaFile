package TexualContentImplement;

public class Document {

	String text ;
	
	public String toString()
	{
		return text ;
		
	}
	
	public void setText(String str)
	{
		text = str ;
		
	}
}
