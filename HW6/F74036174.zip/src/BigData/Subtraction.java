package BigData;

import java.util.ArrayList;

public class Subtraction extends IOperation{
	
	public String perform(String num1, String num2) {

		int carry = 0 ;
		int i , j;
		char ch1,ch2 ;
		int int1,int2,int_sum;
		int length_minux ;
		String compare ;
		String string_sum = "" ;
		String string_zero = "" ;
		String string_neg  = "-";
		ArrayList<String> arrayList = new ArrayList<String>() ;
		Comparison comparison = new Comparison() ;

		//作減法
		if(num1.charAt(0)!='-' && num2.charAt(0)!='-')
		{
			compare = comparison.perform(num1, num2);
			if(compare.equals("0"))
			{
				string_sum = "0";
			}
			else if(compare.equals("1"))
			{
				i = (num1.length()>num2.length())?num1.length():num2.length() ;
				i = i - 1 ;
				length_minux = num1.length() - num2.length() ;
				length_minux = Math.abs(length_minux);
				for(j = 1; j<=length_minux;j++)
				{
					string_zero = string_zero.concat("0");
				}

					num2 = string_zero.concat(num2);//num1 必大於num2
					while(i>=0)
					{
						ch1 = num1.charAt(i);
						ch2 = num2.charAt(i);
						int1 = Character.getNumericValue(ch1);
					    int2 = Character.getNumericValue(ch2);
					    if(carry==1)
					    {
					    	int1 = int1 - 1 ;
					    	carry = 0 ;
					    }
					    if(int1<int2)
					    {
					    	carry = 1 ;
					    	int_sum = (10 - int2) + int1 ;
					    	arrayList.add(Integer.toString(int_sum));
					    }
					    else{
					    	int_sum = int1 - int2 ;
					    	arrayList.add(Integer.toString(int_sum));
					    }
					    i = i - 1 ;
						
					}
					j = arrayList.size() - 1 ;
					while(j>=0)
					{
						string_sum = string_sum.concat(arrayList.get(j));
						j = j - 1 ;
					}
				
				
			}
			
			else if(compare.equals("-1"))
			{
				i = (num1.length()>num2.length())?num1.length():num2.length() ;
				i = i - 1 ;
				length_minux = num1.length() - num2.length() ;
				length_minux = Math.abs(length_minux);
				for(j = 1; j<=length_minux;j++)
				{
					string_zero = string_zero.concat("0");
				}

					num1 = string_zero.concat(num1);//num1 必大於num2
					while(i>=0)
					{
						ch1 = num1.charAt(i);
						ch2 = num2.charAt(i);
						int1 = Character.getNumericValue(ch1);
					    int2 = Character.getNumericValue(ch2);
					    if(carry==1)
					    {
					    	int2 = int2 - 1 ;
					    	carry = 0 ;
					    }
					    if(int2<int1)
					    {
					    	carry = 1 ;
					    	int_sum = (10 - int1) + int2 ;
					    	arrayList.add(Integer.toString(int_sum));
					    }
					    else{
					    	int_sum = int2 - int1 ;
					    	arrayList.add(Integer.toString(int_sum));
					    }
					    i = i - 1 ;
						
					}
					j = arrayList.size() - 1 ;
					string_sum = string_neg.concat(string_sum);
					while(j>=0)
					{
						string_sum = string_sum.concat(arrayList.get(j));
						j = j - 1 ;
					}
				
			}
		}
		//作減法
		else if(num1.charAt(0)=='-' && num2.charAt(0)=='-')
		{
			compare = comparison.perform(num1, num2);
			if(compare.equals("0"))
			{
				string_sum = "0" ;
			}
			else if(compare.equals("1"))//num1比num2大只有可能是num1長度小於等於num2，結果為正
			{
				i = (num1.length()>num2.length())?num1.length():num2.length() ;
				i = i - 1;
				length_minux  = num1.length() - num2.length() ;
				length_minux = Math.abs(length_minux) ;
				num1 = num1.substring(1);
				for(j=1;j<=length_minux;j++)
				{
					string_zero = string_zero.concat("0");
				}
				num1 = string_zero.concat(num1);
				num1 = string_neg.concat(num1);
				while(i>=1)
				{
					ch1 = num1.charAt(i);
					ch2 = num2.charAt(i);
					int1 = Character.getNumericValue(ch1);
					int2 = Character.getNumericValue(ch2);
					if(carry==1)
				    {
				    	int2 = int2 - 1 ;
				    	carry = 0 ;
				    }
				    if(int2<int1)
				    {
				    	carry = 1 ;
				    	int_sum = (10 - int1) + int2 ;
				    	arrayList.add(Integer.toString(int_sum));
				    }
				    else{
				    	int_sum = int2 - int1 ;
				    	arrayList.add(Integer.toString(int_sum));
				    }
					i = i - 1 ;
					
				}
				j = arrayList.size() - 1;
				while(j>=0)
				{
					string_sum = string_sum.concat(arrayList.get(j));
					j = j - 1 ;
				}
			}
			else if(compare.equals("-1"))//num1比num2小只有可能是num2長度小於等於num1，結果為負
			{

				i = (num1.length()>num2.length())?num1.length():num2.length() ;
				i = i - 1;
				length_minux  = num1.length() - num2.length() ;
				length_minux = Math.abs(length_minux) ;
				num2 = num2.substring(1);
				for(j=1;j<=length_minux;j++)
				{
					string_zero.concat("0");
				}
				num2 = string_zero.concat(num2);
				num2 = string_neg.concat(num2);
				while(i>=1)
				{
					ch1 = num1.charAt(i);
					ch2 = num2.charAt(i);
					int1 = Character.getNumericValue(ch1);
					int2 = Character.getNumericValue(ch2);
					if(carry==1)
				    {
				    	int1 = int1 - 1 ;
				    	carry = 0 ;
				    }
				    if(int1<int2)
				    {
				    	carry = 1 ;
				    	int_sum = (10 - int2) + int1 ;
				    	arrayList.add(Integer.toString(int_sum));
				    }
				    else{
				    	int_sum = int1 - int2 ;
				    	arrayList.add(Integer.toString(int_sum));
				    }
					i = i - 1 ;
					
				}
				j = arrayList.size() - 1;
				string_sum = string_neg.concat(string_sum) ;
				while(j>=0)
				{
					string_sum = string_sum.concat(arrayList.get(j));
					j = j - 1 ;
				}
			
		}
		}
		//呼叫加法
		else if(num1.charAt(0)!='-' && num2.charAt(0)=='-')
		{

			Addition addition = new Addition() ;
			num2 = num2.substring(1);
			string_sum = addition.perform(num1, num2);
		}
			
		
		//呼叫加法
		else if(num1.charAt(0)=='-' && num2.charAt(0)!='-')
		{

			Addition addition = new Addition() ;
			num2 = string_neg.concat(num2);

			string_sum = addition.perform(num1, num2);
		}

		return string_sum;
	}

}
