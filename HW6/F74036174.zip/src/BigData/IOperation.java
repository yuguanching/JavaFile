package BigData;

public abstract class IOperation {

	public abstract String perform(String num1,String num2) ;
}

